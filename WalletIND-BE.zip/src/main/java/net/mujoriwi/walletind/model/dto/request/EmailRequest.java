package net.mujoriwi.walletind.model.dto.request;

import lombok.Data;

@Data
public class EmailRequest {
    private String email;
}
