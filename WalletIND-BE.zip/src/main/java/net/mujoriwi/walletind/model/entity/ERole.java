package net.mujoriwi.walletind.model.entity;

public enum ERole {
  SUPER_ADMIN, SUPER_USER, USER
}
