package net.mujoriwi.walletind.exception.custom;

public class CustomBadRequestException extends Exception {

    public CustomBadRequestException(String message) {
        super(message);
    }

}