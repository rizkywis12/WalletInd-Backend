package net.mujoriwi.walletind.exception.custom;

public class CustomNotFoundException extends Exception {

    public CustomNotFoundException(String message) {
        super(message);
    }

}
